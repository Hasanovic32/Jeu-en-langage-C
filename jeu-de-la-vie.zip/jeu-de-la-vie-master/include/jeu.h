/**\file jeu.h 
 *\brief evolution du jeu
 */
#ifndef __JEU_H
#define __JEU_H

#include "grille.h"

/** 
 *\brief variable globale indiquant la periode 
 */
int periode;

/**
 *\brief variable globale indiquant le temps d'evolution
 */
int temps_evolu;

/**
 *\brief modulo modifié pour traiter correctement les bords i=0 et j=0 dans le calcul des voisins avec bords cycliques
 *\param i
 *\param m
 */
static inline int modulo(int i, int m) {return (i+m)%m;}

/**
 *\brief compte le nombre de voisins vivants de la cellule (i,j) les bords sont cycliques.
 *\param i
 *\param j
 *\param grille g
 */
int compte_voisins_vivants_cycliques(int i, int j, grille g);

/** 
 *\brief Compte le nombre de voisins vivants de la cellule (i,j) .Les bords sont non cycliques
 *\param i
 *\param j
 *\param grille g
 */
int compte_voisins_non_cycliques(int i,int j, grille g);

/**
 *\brief fait évoluer la grille g d'un pas de temps
 *\param pointeur grille g
 *\param pointeur grille gc
 */
void evolue (grille *g, grille *gc);

/**
 *\brief teste si deux grille sont egaux
 *\param grille g 
 *\param grille gc
 */
int grille_egaux(grille g, grille gc);

/** 
 *\brief teste si une grille est vide
 *\param grille g
 */
int vide(grille g);

/**
 *\brief calcul d'oscillation
 *\param grille g
 */
int oscillation_cairo(grille g);



#endif
