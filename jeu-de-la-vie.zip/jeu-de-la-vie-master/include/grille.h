/** \file grille.h
 *\brief allocation des grilles
 */
#ifndef __GRILLE_H
#define __GRILLE_H

#include <stdlib.h>
#include <stdio.h>
#include <assert.h>

/**
 *\brief structure grille : nombre de lignes, nombre de colonnes, tableau de tableau de cellules
 */
typedef struct {int nbl; int nbc; int** cellules;} grille;
 
/**
 *\brief alloue une grille de taille l*c, et initialise toutes les cellules à mortes
 *\param l nb de lignes
 *\param c nb colonnes
 *\param g pointeur sur la grille
 */
void alloue_grille (int l, int c, grille* g);

/**
 *\brief libère une grille
 *\param g pointeur sur la grille
 */
void libere_grille (grille* g);

/**
 *\brief alloue et initialise la grille g à partir d'un fichier
 *\param nom fichier
 *\param g pointeur sur la grille
 */
void init_grille_from_file (char * filename, grille* g);

/**
 *\brief rend vivante la cellule (i,j) de la grille g
 *\param i ligne de la cellule
 *\param j de colonne de la cellule
 */
static inline void set_vivante(int i, int j, grille g){g.cellules[i][j] = 1;}

/**
 *\brief rend morte la cellule (i,j) de la grille g
 *\param i
 *\param j
 *\param grille g
 */
static inline void set_morte(int i, int j, grille g){g.cellules[i][j] = 0;}

/**
 *\brief teste si la cellule (i,j) de la grille g est vivante
 *\param i
 *\param j
 *\param grille g
 */
static inline int est_vivante(int i, int j, grille g)
	{return g.cellules[i][j] > 0;}

/**
 *\brief teste si la cellule(i,j) est viable 
 *\param i
 *\param j
 *\param grille g
 */
static inline int viables(int i, int j, grille g)
	{return g.cellules[i][j] >=0;}

/**
 *\brief continue le jeu sans viellissement
 *\param i 
 *\param j
 *\param grille g
 */
void non_viellit(int i,int j, grille g);

/**
 *\brief continue le jeu avec viellissement
 *\param i
 *\param j
 *\grille g
 */
void viellit(int i, int j, grille g);

/**
 *\brief rend non viables la cellule (i,j) de grille g
 *\param i ligne de la cellule
 *\param j colonne de la cellule
 *\param g grille g
 */
static inline void nonviables(int i, int j, grille g)
{
	g.cellules[i][j] = -1;}
	
/**
 *\brief recopie gs dans gd (sans allocation)
 *\param grille gs
 *\param grille gd
 */

void copie_grille (grille gs, grille gd);

#endif
