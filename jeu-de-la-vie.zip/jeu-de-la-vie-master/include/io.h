/**\file io.h
 *\brief affichage des grilles et déclaration des touches nécessaire
 */
#ifndef __IO_H
#define __IO_H

#include <stdio.h>
#include "grille.h"
#include "jeu.h"

/**
 *\brief variable globale definie dans io.c
 */
int non_periode;

/**
 *\brief variable globale definie dans jeu.c
 */
extern int temps_evolu;

/**
 *\brief variable definie dans jeu.c
 */
extern int periode;

/** 
 *\brief pointeur de fonction definie dans jeu.c
 *\param int 
 *\param int
 *\grille
 */
extern int (*compte_voisins_vivants) (int,int,grille);
/**
 *\brief pointeur de fonction definie dans jeu.c
 *\param int 
 *\param int 
 *\grille
 */

extern void (*viellissement) (int, int ,grille);

/**
 *\brief affichage d'un trait horizontal
 *\param c nb colonnes
 */
void affiche_trait (int c);

/**
 *\brief affichage d'une ligne de la grille
 *\param c nb colonnes
 *\param pointeur ligne
 */
void affiche_ligne (int c, int* ligne);

/**
 *\brief affichage d'une grille
 *\param grille g
 */
void affiche_grille (grille g);


/**
 *\brief effacement d'une grille
 *\param grille g
 */
void efface_grille (grille g);

/**
 *\brief debute le jeu
 *\param grille g en cours
 *\param grille gc
 */
void debut_jeu(grille *g, grille *gc);

#endif
