/**\file io_cairo.h
 *\author Hassan TAHA
 *\brief fichier d'entete de io_cairo.c
 */
#ifndef __IO_CAIRO_H
#define __IO_CAIRO_H

#include <stdio.h>
#include <stdlib.h>
#include <cairo.h>
#include <cairo-xlib.h>
#include <X11/Xlib.h>

#include "grille.h"
#include "jeu.h"

/** 
 *\brief variable globale definie dans jeu.c
 */
extern int temps_evolu;

/**
 *\brief variable globale definie dans jeu.c
 */
extern int periode;

/** 
 *\brief affichage de la grille
 *\param surface cairo
 *\param grille g
*/
void paint(cairo_surface_t *surface, grille g);

/**
 *\brief demarre le jeu cairo
 *\param grille g
 *\param grille gc pour la fonction evolue
*/
void debut_jeu_cairo(grille *g, grille *gc);

/**
 *\brief change le mode du voisinage
 */
void cyclique_cairo();

/**
 *\brief change le mode du viellissement
 */
void viellissement_cairo();

/**
 *\brief increment le temps d'evolution
 */
void temps_evolut();

/**
 *\brief reinitialse le temps d'evolution à 0
 */
 
void temps_init();

/**
 *\brief affiche la periode graphiquement 
 *\param surface
 *\param grille g
 */ 
void affiche_periode(cairo_surface_t* surface, grille g);





#endif
