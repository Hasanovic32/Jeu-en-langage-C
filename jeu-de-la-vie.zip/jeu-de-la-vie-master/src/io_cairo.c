/**\file io_cairo.c
 *\author Hassan TAHA
 *\brief evolution du jeu dans le mode graphique
*/
#include "io_cairo.h"


extern int temps_evolu; // definie dans jeu.c
extern int periode; // definie dans jeu.c

extern int (*compte_voisins_vivants) (int, int , grille); // defini dans jeu.c
extern void (*viellissement) (int, int, grille); // defini dans jeu.c 

void paint(cairo_surface_t *surface, grille g){
	int l = g.nbl, c = g.nbc;
	char t[4]; // tableau pour le temps d'evolution 
	
	//create cairo mask
	cairo_t *cr;
	cr = cairo_create(surface);
	
	//background
	cairo_set_source_rgb(cr, 0, 0.7, 10);
	cairo_paint(cr);
	
	//TEXTE: Temps d'évolution
	cairo_select_font_face(cr,"sans-serif",CAIRO_FONT_SLANT_NORMAL,CAIRO_FONT_WEIGHT_BOLD);
	cairo_set_font_size(cr,18.0);
	sprintf(t, "%d", temps_evolu);
	cairo_move_to(cr, 740,250);
	cairo_set_source_rgb(cr,1,1,1);
	cairo_show_text(cr, "Temps d'évolution: ");
	cairo_show_text(cr, t);
	
	//TEXTE: Viellissement
	cairo_select_font_face(cr,"sans-serif",CAIRO_FONT_SLANT_NORMAL,CAIRO_FONT_WEIGHT_BOLD);
	cairo_set_font_size(cr,18.0);
	cairo_move_to(cr,740,100);
	cairo_set_source_rgb(cr,1,1,1);
	cairo_show_text(cr, "Vieillissement ");
	cairo_rectangle(cr,900,85,20,20);// affichage de button ON/OFF en couleur
	if(viellissement == non_viellit) 
		cairo_set_source_rgb(cr,1,0,0); // viellissement désactiver = carre rouge
	else cairo_set_source_rgb(cr,0,1,0); // viellissement activer = carre vert
	cairo_fill(cr);
	
	//TEXTE: Cyclique
	cairo_select_font_face(cr,"sans-serif",CAIRO_FONT_SLANT_NORMAL,CAIRO_FONT_WEIGHT_BOLD);
	cairo_set_font_size(cr,18.0);
	cairo_move_to(cr,740,150);
	cairo_set_source_rgb(cr,1,1,1);
	cairo_show_text(cr, "Cyclique ");
	cairo_rectangle(cr,900,135,20,20);// affichage de button ON/OFF en couleur
	if( compte_voisins_vivants == compte_voisins_vivants_cycliques)
		cairo_set_source_rgb(cr,0.0,1,0.0);// voisinage cyclique = carre vert
	else cairo_set_source_rgb(cr,1,0.0,0.0); // non cyclique = carre rouge
	cairo_fill(cr);
	
	
	cairo_set_source_rgb(cr,1,1,1);
	cairo_set_line_width(cr,3);
	
	//colonne
	for(int i =0; i<=c ; i++){
		cairo_move_to(cr,10+i*50,10);
		cairo_line_to(cr,10+50*i,10+l*50);
		cairo_stroke(cr);
	}
	//ligne
	for (int j=0;j<=l; j++){
		cairo_move_to(cr,10,10+j*50);
		cairo_line_to(cr,10+50*c,10+j*50);
		cairo_stroke(cr);
	}
	for (int i = 0; i<l;i++){
		for(int j =0; j<c ;j++){
			cairo_select_font_face(cr,"sans-serif", CAIRO_FONT_SLANT_NORMAL,CAIRO_FONT_WEIGHT_BOLD);
			cairo_set_font_size(cr,25.0);
			cairo_set_source_rgb(cr,0,0,0);
			
			//cellules non viables
			if (g.cellules[i][j]== -1){
				cairo_set_source_rgb(cr,1,0,0);
				cairo_rectangle(cr,50*j+10,50*i+10,48,48);
				cairo_fill(cr);
				cairo_set_source_rgb(cr,0, 0, 0);
				cairo_move_to(cr,23+j*50, i*50+47);
			}
			//cellules vivantes
			else if (est_vivante(i,j,g)){
				cairo_set_source_rgb(cr,0,0.2,0.5);
				cairo_rectangle(cr,50*j+10,50*i+10,48,48);
				cairo_fill(cr);
				cairo_set_source_rgb(cr,1,1,1);
				cairo_move_to(cr,23+j*50, i*50+46);
			// affichage de l'age de la cellule		
				int age = g.cellules[i][j];
				char age1[2];
				if(viellissement == viellit){
					sprintf(age1, "%d" ,age);
					cairo_text_extents_t text;
					cairo_text_extents(cr ,age1, &text);
					cairo_show_text(cr,age1);
				}
				else { cairo_show_text(cr,"O");}
			}
			else{
				cairo_set_source_rgb(cr,1,1,1);
			}
		}
	}
	cairo_destroy(cr); //destroy cairo mask
}

void debut_jeu_cairo(grille* g, grille* gc){
	evolue(g,gc); 
}


void cyclique_cairo(){
	if(compte_voisins_vivants == compte_voisins_vivants_cycliques) 
		compte_voisins_vivants = compte_voisins_non_cycliques;
	else compte_voisins_vivants = compte_voisins_vivants_cycliques;
}

void viellissement_cairo(){
	if(viellissement == viellit)
		viellissement = non_viellit;
	else viellissement = viellit;
}

void temps_evolut(){
	temps_evolu++;
}

void temps_init(){
	temps_evolu = 0;
}



void affiche_periode(cairo_surface_t* surface,grille g){
	cairo_t *cr;
	cr = cairo_create(surface);
	char p[2];//tableau pour la periode 
	//TEXTE: Periode
	cairo_select_font_face(cr,"sans-serif",CAIRO_FONT_SLANT_NORMAL,CAIRO_FONT_WEIGHT_BOLD);
	cairo_set_font_size(cr,18.0);
	periode = oscillation_cairo(g);
	sprintf(p, "%d", periode);
	cairo_move_to(cr,740,200);
	cairo_set_source_rgb(cr,1,1,1);
	cairo_show_text(cr,"Période: ");
	cairo_show_text(cr,p);
}
			
			
			


	
	
	
	
	
	
					
		
	
	
	

