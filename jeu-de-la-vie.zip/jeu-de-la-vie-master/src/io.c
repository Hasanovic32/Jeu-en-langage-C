/**\file io.c
 *\author Hassan TAHA
 *\brief affichage de la grille
 */
#include "io.h"

extern int temps_evolu; // defini dans jeu.c

int non_periode = 0; 

extern int periode; // defini dans jeu.c

//on doit utiliser le pointeur de fonction définie en jeu.c
extern int (*compte_voisins_vivants) (int,int,grille);

//on doit utiliser le pointeur de fonction définie en jeu.c
extern void (*viellissement) (int,int,grille);

void affiche_trait (int c){
	int i;
	for (i=0; i<c; ++i) printf ("|---");
	printf("|\n");
	return;
}

void affiche_ligne (int c, int* ligne){
	int i;
	if (viellissement == non_viellit)
	{
	for (i =0; i<c ; ++i)
		if(ligne[i]==0) printf("|   "); else if (ligne[i] == -1) printf("| X ");else printf("| O ");
	printf("|\n");
	}
	else{
		for (i = 0;i<c; ++i)
			if(ligne[i] == 0) printf("|   "); else if (ligne[i] == -1) printf("| X "); else printf("| %d ", ligne[i] );
	printf("|\n");
	}
	return;
}

void affiche_grille (grille g){
	int i, l=g.nbl, c=g.nbc;
	printf("Temps d'evolution: %d \t", temps_evolu);
	if(compte_voisins_vivants == compte_voisins_vivants_cycliques) printf("Voisinage: ON\t");
	else printf("Voisinage: OFF\t");
	if( viellissement == non_viellit) printf("Viellissement: OFF\t");
	else printf("Viellissement: ON\t");
	if (non_periode == 1) printf("période:%d \t",periode); 
	printf("\n");
	affiche_trait(c);
	for (i=0; i<l; ++i) {
		affiche_ligne(c, g.cellules[i]);
		affiche_trait(c);
	}	
	printf("\n"); 
	return;
}

void efface_grille (grille g){
	printf("\n\e[%dA",(g.nbl-2)*2 + 5); 
	system("clear");
}

void debut_jeu(grille *g, grille *gc){
	char c = getchar(); 
	int reboucle = 0; // important pour que la grille ne dépasse pas une étape 
	while (c != 'q') // touche 'q' pour quitter
	{ 
		switch (c) {
			case '\n' : 
			{ // touche "entree" pour évoluer
				if (reboucle == 0){
				temps_evolu++; // incrementer le temps d'evolution
				evolue(g,gc);
				efface_grille(*g);
				printf("\n\e[A");
				affiche_grille(*g);
				non_periode = 0;
				periode = 0;
				}
				reboucle = 0;
				
				break;
			}
			case 'n' : // touche n pour changer la grille qu'on veut l'afficher
			{
				char nom_grille[50];
				printf("Nom de grille: \n");
				scanf("%s", nom_grille);
				
				compte_voisins_vivants = compte_voisins_vivants_cycliques;
				temps_evolu = 0; // reinitaliser le temps d'evolution à 0 apres le changement de grille
				viellissement = non_viellit;
				efface_grille(*g); //effacement des grilles qui sont deja affichées
				libere_grille(g); // Reinitialisation de grille à 0 (liberation des grilles)
				libere_grille(gc);
				system("clear");
				init_grille_from_file(nom_grille,g);
				alloue_grille((g->nbl),(g->nbc),gc);
				reboucle = 1;
				break;
				}
			case 'c' : //Touche c pour activer / désactiver le voisinage cyclique
			{ //Le voisinage est cyclique par defaut 
				if (compte_voisins_vivants == compte_voisins_non_cycliques)
				{
				compte_voisins_vivants=compte_voisins_vivants_cycliques;	
					//cyclique = 0;
					
				}
				else 
				{
					//cyclique =1;
					compte_voisins_vivants = compte_voisins_non_cycliques;
				}
				reboucle = 1;
				break;
			}
			case 'v':// touche v pour activer ou désactiver le vieillissement de cellules
			{
				if (viellissement == non_viellit) 
				{
					viellissement = viellit;
				}
				else {
					viellissement = non_viellit;
					
				}
				reboucle = 1;
				break;
			
			}
			case 'o': // touche o pour afficher la periode
			{
				non_periode = 1;
				periode = oscillation_cairo(*g);
				reboucle =1;
				break;
			}
			
			
			default : 
			{ // touche non traitée
				printf("\n\e[1A");
				break;
			}
		}
		efface_grille(*g);
		affiche_grille(*g);
		c = getchar(); 
	}
	return;	
}
