/**\file grille.c
 *\author Hassan TAHA
 *\brief initialisation des grilles
 */
#include "grille.h"


void alloue_grille(int l, int c, grille* g){
	g->nbl = l; //initialisation de nombre de lignes dans l
	g-> nbc = c; //inistailisation de nombre de colonne dans c
	g-> cellules = (int**) malloc (l *sizeof(int*)); //on crée le tableau dynamique de cellules
	assert(g-> cellules != NULL);
	for (int i =0; i<l; i++)
	{
		g-> cellules[i] = (int*) malloc (c *sizeof(int));
		assert (g-> cellules[i] != NULL);
	}

	for (int i =0; i<l; i++)
	{
		for(int j = 0; j<c; j++)
		{
			set_morte(i,j, *g);
		}
	}

}

void non_viellit(int i, int j , grille g){
}

void viellit( int i, int j, grille g){
	g.cellules[i][j] = (g.cellules[i][j]+1) % 9;
}



void libere_grille (grille* g){

	for(int i =0; i< g->nbl; i++)
	{
		free( g->cellules[i]);
	}
	free( g-> cellules);
	g -> nbl =0; // on reinitialise le nombre de ligne à 0
	g ->cellules = NULL; //on reinitialise le tableau de cellules à NULL
	g -> nbc = 0; // on reinitilaise le nombre de colonne à 0
}


void init_grille_from_file (char * filename, grille* g){
	FILE * pfile = NULL;
	pfile = fopen(filename, "r");
	assert (pfile != NULL);

	int i,j,n,l,c,vivantes=0;

	fscanf(pfile, "%d", & l);
	fscanf(pfile, "%d", & c);
	alloue_grille(l,c,g);

	fscanf(pfile, "%d", & vivantes);
	for (n=0; n< vivantes; ++n){
		fscanf(pfile, "%d", & i);
		fscanf(pfile, "%d", & j);
		set_vivante(i,j,*g);
	}
	
	int non_viables;
	fscanf(pfile, "%d", &non_viables);
	for(n= 0; n<non_viables;n++)
	{
		fscanf(pfile, "%d", &i);
		fscanf(pfile, "%d", &j);
		nonviables( i,j , *g);
	}
	

	fclose (pfile);
	system("clear");
	return;
}


void copie_grille (grille gs, grille gd){
	int i, j;
	for (i=0; i<gs.nbl; ++i) for (j=0; j<gs.nbc; ++j) gd.cellules[i][j] = gs.cellules[i][j];
	return;
}
