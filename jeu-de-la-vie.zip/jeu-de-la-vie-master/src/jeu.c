/**\file jeu.c
 *\author Hassan TAHA
 *\brief Declaration des fonctions d'evolution 
*/
#include "jeu.h"

//on crée un pointeur de fonction qui pointe sur la fonction de calcul cyclique , et pour que le voisisnage soit cyclique par defaut
int (*compte_voisins_vivants) (int, int, grille)= compte_voisins_vivants_cycliques;

//on crée un pointeur de fonction qui pointe sur la fonction non_viellit, pour que le viellissement soit désactiver par défaut 
void (*viellissement)(int,int,grille)  = non_viellit ;

int temps_evolu = 0;
int periode = 0;

int compte_voisins_vivants_cycliques (int i, int j, grille g){
	int v = 0, l=g.nbl, c = g.nbc;
	v+= est_vivante(modulo(i-1,l),modulo(j-1,c),g);
	v+= est_vivante(modulo(i-1,l),modulo(j,c),g);
	v+= est_vivante(modulo(i-1,l),modulo(j+1,c),g);
	v+= est_vivante(modulo(i,l),modulo(j-1,c),g);
	v+= est_vivante(modulo(i,l),modulo(j+1,c),g);
	v+= est_vivante(modulo(i+1,l),modulo(j-1,c),g);
	v+= est_vivante(modulo(i+1,l),modulo(j,c),g);
	v+= est_vivante(modulo(i+1,l),modulo(j+1,c),g);

	return v; 
}

int compte_voisins_non_cycliques(int i, int j, grille g){
	//on demarre avec le meme prototype  de la fonction compte_voisins_vivants_cycliques
	int v= 0, l=g.nbl, c = g.nbc;
	if (i>0) 
	{
		if(j>0) 
		{
			v+= est_vivante(i-1,j-1 ,g);
		}
		v += est_vivante(i-1,j,g);
		
		if (j < c-1 ) 
		{
			v+= est_vivante(i- 1,j+1,g);
		}
	}
	
	if (j>0)
	{
		v+= est_vivante(i,j-1,g);
	}
	if (j<c-1)
	{
		v += est_vivante(i, j+1,g);
	}
	
	if (i <l-1)
	{
		if (j> 0)
		{
			v+= est_vivante (i+1, j-1 ,g);
		}
		v+= est_vivante(i+1,j,g);
		
		if (j<c-1) 
		{
			v+= est_vivante(i+1,j+1,g);
		}
	}
	return v;	
}


void evolue (grille *g, grille *gc){
	copie_grille (*g,*gc); // copie temporaire de la grille
	int i,j,l=g->nbl, c = g->nbc,v;
	if (compte_voisins_vivants == compte_voisins_vivants_cycliques)
	{
		compte_voisins_vivants = compte_voisins_vivants_cycliques;
	}
	else 
	{
		compte_voisins_vivants = compte_voisins_non_cycliques;
	}
	for (i = 0; i<l; i++) 
	{
		for (j=0; j<c; ++j)
		{
			if (viables(i,j,*g)){
				v = compte_voisins_vivants (i,j,*gc);
				if(est_vivante(i,j,*g))
				{ // evolution d'une cellule vivante
					if(v!=2 && v!=3) set_morte(i,j, *g);
					else viellissement(i,j,*g);
				}
				else
				{ // evolution d'une cellule morte			
					if (v==3) set_vivante(i,j,*g);
				}
	
			}
		}	
	}			
	return;
}

int grille_egaux(grille g, grille g1){
	for(int i =0;i<g.nbl;i++){
		for (int j = 0;j<g.nbc;j++){
			if (g.cellules[i][j] != g1.cellules[i][j]) return 0;
			
		}
	}
	return 1;
}

int vide(grille g){
	int l = g.nbl, c = g.nbc;
	for (int i = 0 ; i<l;i++){
		for (int j = 0;j<c;j++){
			if (g.cellules[i][j]> 0) return 0;
		}
	}
	return 1;
}

int oscillation_cairo(grille g){
	int l = g.nbl, c = g.nbc;
	int nbrOsc;
	grille g1,g2,g3;// g2 et g3 sont les paramteres de la fonction evolue 
	alloue_grille(l,c,&g1);
	copie_grille(g,g1);
	alloue_grille(l,c,&g2);
	copie_grille(g,g2);
	alloue_grille(l,c,&g3);
	copie_grille(g,g3);
	
	do{
	while (nbrOsc < 999 ){
		evolue(&g2,&g3);
		nbrOsc ++;
	// teste si la grille est vide
	if (vide(g1)){
		libere_grille(&g1);
		libere_grille(&g2);
		libere_grille(&g3);
		periode = 1;
		return periode;
	}
	
	
	// teste si les grilles sont egaux
	if (grille_egaux(g1,g2)){
		libere_grille(&g1);
		libere_grille(&g2);
		libere_grille(&g3);
		return nbrOsc;
		}
	}
	evolue(&g1,&g3);
	copie_grille(g1,g2);
	// on retourne à la premiere position
	nbrOsc = 0;
	periode ++;
	}while (periode < 999);
	
	libere_grille(&g1);
	libere_grille(&g2);
	libere_grille(&g3);
	return 0;
}
