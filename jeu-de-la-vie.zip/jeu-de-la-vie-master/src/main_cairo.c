/** \file main_cairo.c
 *\author Hassan Taha
 *\brief fonction main_cairo pour le mode graphique
*/
#include <stdio.h>
#include <stdlib.h>
#include <cairo.h>
#include <cairo-xlib.h>
#include <X11/Xlib.h>

#include "io_cairo.h"


#define SIZEX 1000
#define SIZEY 550



//on doit utiliser le pointeur de fonction définie en jeu.c
extern int (*compte_voisins_vivants) (int,int,grille);
//on doit utiliser le pointeur de fonction définie en jeu.c
extern void (*viellissement) (int,int,grille);

int main(int argc, char ** argv){
	
	if(argc != 2)
	{
		printf("usage: main<fichier grille \n");
		return 1;
	}
	
	grille g, gc;
	init_grille_from_file(argv[1],&g);
	alloue_grille(g.nbl, g.nbc, &gc);
	
	
	// X11 display
	Display *dpy;
	Window rootwin;
	Window win;
	XEvent e;
	int scr;
	
	// init the display
	if(!(dpy=XOpenDisplay(NULL))) {
		fprintf(stderr, "ERROR: Could not open display\n");
		exit(1);
	}

	scr=DefaultScreen(dpy);
	rootwin=RootWindow(dpy, scr);

	win=XCreateSimpleWindow(dpy, rootwin, 1, 1, SIZEX, SIZEY, 0, 
			BlackPixel(dpy, scr), BlackPixel(dpy, scr));

	XStoreName(dpy, win, "Jeu de la vie - Hassan TAHA");
	XSelectInput(dpy, win, ExposureMask|ButtonPressMask|KeyPressMask);
	XMapWindow(dpy, win);
	
	// create cairo surface
	cairo_surface_t *cs; 
	cs=cairo_xlib_surface_create(dpy, win, DefaultVisual(dpy, 0), SIZEX, SIZEY);

	// run the event loop
	while(1) {
		XNextEvent(dpy, &e);
		if(e.type==Expose && e.xexpose.count<1) {
			paint(cs,g);
		} 
		else if(e.type==ButtonPress && e.xbutton.button == Button1){
			debut_jeu_cairo(&g,&gc);
			temps_evolut();
			paint(cs,g);
		}
		// click droit
		else if(e.type == ButtonPress && e.xbutton.button == Button3){
		
			break;
		}
		//touche 'c' voisinage
		else if(e.type == KeyPress && e.xkey.keycode == 54){
			cyclique_cairo();
			paint(cs,g);
		}
		//touche 'v' viellissement
		else if (e.type == KeyPress && e.xkey.keycode == 55){
			viellissement_cairo();
			paint(cs,g);
		}
		//touche 'n' changer la grille
		else if (e.type == KeyPress && e.xkey.keycode == 57){
				libere_grille(&g); // Reinitialisation de grille à 0 (liberation des grilles)
				libere_grille(&gc);
				char nom_grille[50];
				printf("Nom de grille: \n");
				scanf("%s", nom_grille);
				
				compte_voisins_vivants = compte_voisins_vivants_cycliques;//le voisinage est cyclique par defaut
				temps_init(); // reinitaliser le temps d'evolution à 0 apres le changement de grille
				viellissement = non_viellit;//viellissement est désactiver par défaut
				//efface_grille(*g); //effacement des grilles qui sont deja affichées
		
				//system("clear");
				init_grille_from_file(nom_grille,&g);
				alloue_grille(g.nbl,g.nbc,&gc);
				paint(cs,g);
		
		}
		//touche 'o' oscillation
		else if (e.type == KeyPress && e.xkey.keycode == 32){
			affiche_periode(cs,g);
		 }
	}

	cairo_surface_destroy(cs); // destroy cairo surface
	XCloseDisplay(dpy); // close the display
	libere_grille(&g);
	libere_grille(&gc);
	return 0;
}
